# Uploads the launcher SOURCE (the folder "launcher" and the workflow) into your GitHub repo with your own gh.exe login.
# No git needed. Put this file in the unzipped "launcher-source" folder and run Upload-Launcher-Source.bat.
$ErrorActionPreference = 'Continue'
$Root = $PSScriptRoot
$Gh   = 'D:\Coding\Github CLI\bin\gh.exe'
$Repo = 'SyedNekoChan/wow-ra-server'
if (-not (Test-Path $Gh)) { Write-Host ('gh.exe not found at ' + $Gh); exit 1 }

$files = Get-ChildItem -Path $Root -Recurse -File | Where-Object {
    $_.FullName -notmatch '\\(node_modules|target|dist)\\' -and $_.Name -notlike 'upload-launcher-source*' -and $_.Name -ne 'Upload-Launcher-Source.bat' -and $_.Name -ne 'Build-Launcher.bat'
}
$n = 0
$failed = 0
foreach ($f in $files) {
    $n++
    $rel = $f.FullName.Substring($Root.Length + 1).Replace('\', '/')
    Write-Host ('[' + $n + '/' + @($files).Count + '] ' + $rel)
    $b64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($f.FullName))
    $sha = & $Gh api ('repos/' + $Repo + '/contents/' + $rel) --jq '.sha' 2>$null
    $body = @{ message = ('Add launcher file: ' + $rel); content = $b64 }
    if ($LASTEXITCODE -eq 0 -and $sha) { $body['sha'] = ($sha | Select-Object -First 1) }
    $tmp = [System.IO.Path]::GetTempFileName()
    [System.IO.File]::WriteAllText($tmp, ($body | ConvertTo-Json -Compress), (New-Object System.Text.UTF8Encoding($false)))
    & $Gh api -X PUT ('repos/' + $Repo + '/contents/' + $rel) --input $tmp 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { Write-Host ('   FAILED: ' + $rel); $failed++ }
    Remove-Item $tmp -Force
}
Write-Host ''
if ($failed -eq 0) { Write-Host 'All files uploaded.' } else { Write-Host ($failed.ToString() + ' file(s) failed. Run this again.') }
if ($failed -eq 0) {
    Write-Host 'Starting the Windows build on GitHub (about 10 to 20 minutes) ...'
    Start-Sleep -Seconds 10
    & $Gh workflow run launcher-build.yml -R $Repo
    if ($LASTEXITCODE -eq 0) { Write-Host 'Build started. When it is done, the exe is on https://github.com/SyedNekoChan/wow-ra-server/releases (tag launcher-v0.1.0).' }
    else { Write-Host 'Could not start the build. Wait a minute, then double-click Build-Launcher.bat.' }
}
