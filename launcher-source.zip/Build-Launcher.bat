@echo off
"D:\Coding\Github CLI\bin\gh.exe" workflow run launcher-build.yml -R SyedNekoChan/wow-ra-server
echo.
echo If it says "Created workflow_dispatch event", the build started (10 to 20 minutes).
echo The exe will appear at https://github.com/SyedNekoChan/wow-ra-server/releases
pause
